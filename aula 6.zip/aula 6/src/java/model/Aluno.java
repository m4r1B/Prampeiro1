/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aluno
 */
public class Aluno {
    private String nome;
    private double nota1;
    private double nota2;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) throws Exception{
        if (nome.length()>=2)
            this.nome= nome;
        else{
            throw new Exception("Nome muito pequeno.");
        }
    }

    /**
     * @return the nota1
     */
    public double getNota1(){
        return nota1;
    }

    /**
     * @param nota1 the nota1 to set
     */
    public void setNota1(double nota1)throws Exception{
        if ((nota1>=0) && (nota1<=10)){
            this.nota1 = nota1;
        }
        else{
            throw new Exception("Nota inválida, deve estar entre[0,10].");
    }
    }
    public void setNota1(String nota1) throws Exception {
        this.setNota1(Double.parseDouble(nota1));
    }

    /**
     * @return the nota2
     */
    public double getNota2() {
        return nota2;
    }

    /**
     * @param nota2 the nota2 to set
     */
    public void setNota2(double nota2)throws Exception{
        if ((nota2>=0) && (nota2<=10)){
            this.nota2 = nota2;
        }
        else{
            throw new Exception("Nota inválida, deve estar entre[0,10].");
    }}
    public void setNota2(String nota2) throws Exception {
        this.setNota2(Double.parseDouble(nota2));
    }
    
    public String getSituacao(){
        String sit="Aprovado";
        double med;
        med=(this.nota1+this.nota2)/2.0;
        
        if(med<4)
            sit="Reprovado";
        if (med<6)
            sit="Recuperação";
        return(sit);
    }
}
